<style>.margin-cls{    margin-top: 12%;}
.alert {
  padding: 20px;
  background-color: #00a65a; /* Red */
  color: white;
  margin-bottom: 15px;
}

/* The close button */
.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

/* When moving the mouse over the close button */
.closebtn:hover {
  color: black;
}

</style>
<section class="cart-table" id="cart-table">
     <div class="container">
	 
    <div class="row margin-cls">
	<div class="col-sm-1 col-md-2 "></div>
	<div class="col-sm-8 col-md-8 ">
	<div class="alert">
 
<p>Your payment has been paid successfully. you will download your paid data after 24 hours.Download link automatically show in Purchased Data page on dashbaord after 24 hours
		
		</p>
</div>
	</div>
	<div class="col-sm-2 col-md-2 "></div>
    </div>
</div>
    </section>