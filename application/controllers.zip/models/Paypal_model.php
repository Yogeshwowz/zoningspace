<?php

class Paypal_model extends CI_Model{

	
}
?>